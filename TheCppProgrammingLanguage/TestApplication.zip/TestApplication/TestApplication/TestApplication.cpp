﻿// TestApplication.cpp : このファイルには 'main' 関数が含まれています。プログラム実行の開始と終了がそこで行われます。
//

#include "pch.h"
#include "Vector.h"
#include <iostream>

// using namespace std;


enum class Color
{
	red,
	blue,
	green
};

enum class Traffic_light : int
{
	green,
	yellow,
	red
};

Traffic_light& operator++(Traffic_light& t)
{
	switch (t)
	{
	case Traffic_light::green:
		return t = Traffic_light::yellow;
	case Traffic_light::yellow:
		return t = Traffic_light::red;
	case Traffic_light::red:
		return t = Traffic_light::green;
	default:
		std::cerr << "Traffic_light#operator++ unknown value" << std::endl;
		return t;
	}
}

void test_traffic_light()
{
	Traffic_light trafic_light = Traffic_light::yellow;
	if (trafic_light == Traffic_light::yellow)
	{
		std::cout << "(1) yellow" << std::endl;
	}
	else
	{
		std::cout << "(1) not yellow" << std::endl;
	}

	++trafic_light;
	if (trafic_light == Traffic_light::yellow)
	{
		std::cout << "(2) yellow" << std::endl;
	}
	else if (trafic_light == Traffic_light::red)
	{

		std::cout << "(2) red" << std::endl;
	}
}

int main()
{
	std::cout << "Hello World!\n";

	//std::cout << read_and_sum(3);

	Vector v2 = Vector(2);
	Vector v3 = Vector(3);
	Vector::f(Vector(1), v2, &v3);

	Color x = Color::red;
	test_traffic_light();

}
